'''## 异常处理
全局捕捉异常，并
- 在控制台打印
- 输出到文件
- 显示错误窗口(使用内置tkinter, 可关闭)
#### 检查更新方法 `ErrorHook.update.get()`
### code by: cc1287'''
from ErrorHook.clib import *